import mysql from 'mysql';
const jwt = require('jsonwebtoken');


export const handler = async (event) => {
    // Specify credentials
    const pool = mysql.createPool({
        host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Netro7887",
        database: "tables4u"
    });
    // TODO: Change me.
    const deleted_rest_uuid = event.rest_uuid;

    const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret-key'; // Set in Lambda environment variables

    const { username, password } = JSON.parse(event.body); // Get the username and password from the request body

    if (!username || !password) {
        return {
            statusCode: 400,
            body: JSON.stringify({ message: 'Username and password are required' }),
        };
    }

    const query = 'SELECT * FROM Administrators WHERE userName = ?';

    try {
        const [rows] = await pool.promise().query(query, [username]);

        if (rows.length === 0) {
            return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Invalid username or password' }),
            };
        }
        // Check if password matches (assuming password is hashed in the database)
        const user = rows[0];

        // We're assuming the password is stored as plain text.
        if (user.pass !== password) {
            return {
                statusCode: 401,
                body: JSON.stringify({ message: 'Invalid username or password' }),
            };
        }

        // Generate a JWT token
        const token = jwt.sign({ userUUID: user.adminUUID, userName: user.userName }, JWT_SECRET, {
            expiresIn: '1h', // Token expires in 1 hour
        });

        // Return the token to the user
        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Login successful', token }),
        };
    } catch (err) {
        console.error('Error:', err);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Internal server error' }),
        };
    }
};