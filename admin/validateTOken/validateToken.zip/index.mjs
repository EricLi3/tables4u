import jwt from 'jsonwebtoken';

export const handler = async (event) => {
    const JWT_SECRET = process.env.JWT_SECRET || 'your-jwt-secret-key'; // Set in Lambda environment variables

    // Extract the token from the Cookie header
    const token = event.headers.Cookie?.split('token=')[1];

    if (!token) {
        return {
            statusCode: 401,
            body: JSON.stringify({ message: 'Token is required' }),
        };
    }

    try {
        // Verify and decode the token
        const decoded = jwt.verify(token, JWT_SECRET);

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Token is valid', decoded }),
        };
    } catch (err) {
        console.error('Error:', err);
        return {
            statusCode: 401,
            body: JSON.stringify({ message: 'Invalid token' }),
        };
    }
};