import mysql from 'mysql';
import { v4 as uuidv4 } from 'uuid';

export const handler = async (event) => {

    // Specify credentials
    const pool = mysql.createPool({
        host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Netro7887",
        database: "tables4u"
    });
    
    const myUUID = uuidv4();
    const user = genUserName();
    const pass = genPassword();

    const query = "INSERT INTO Restaurants (restUUID, userName, pass, restName, address, openingHour, closingHour, isActive) VALUES (?, ?, ?, 'Tables4u','Buy me a hot cocoa', 8, 17, 0)";

    const queryPromise = (query, params) => {
        return new Promise((resolve, reject) => {
            pool.query(query, params, (error, results) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(results);
                }
            });
        });
    };

    let response;

    try {
        await queryPromise(query,[myUUID,user,pass]);

        response = {
            statusCode: 200,
            body: `{"username": "${user}", "password": "${pass}", "sessionToken": "Heineman2024isTheRealHeisenberg2008", "restUUID": "${myUUID}"}`
        };

    } catch (error) {
        response = {
            statusCode: 400,
            body: {"error": "Failure creating restaurant"}
        }
    }
    

    pool.end();

    return response;

    function genUserName(){
        return uuidv4();
    }

    function genPassword(){
        return uuidv4();
    }
};
