import mysql from "mysql";

export const handler = async (event) => {
  const pool = mysql.createPool({
    host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "Netro7887",
    database: "tables4u",
  });

  // //EXample of the data structure
  // const [availabilityData, setAvailabilityData] = useState<{
  //   startTime: number;
  //   endTime: number;
  //   usage: {
  //     day: string;
  //     state: string;
  //     tables: {
  //       name: string;
  //       seats: string;
  //       times: { time: string; people: string }[];
  //     }[];
  //   }[];
  // }>({
  //   startTime: 8,
  //   endTime: 17,
  //   usage: [],
  // });

  const { restUUID, dateRangeStart, dateRangeEnd } = event;

  // validation of inputs
  if (!restUUID || !dateRangeStart || !dateRangeEnd) {
    return {
      statusCode: 400,
      error: "Invalid input parameters.",
    };
  }

  // //rangeEnd must be after rangeStart
  // if (new Date(dateRangeEnd) < new Date(dateRangeStart)) {
  //   return {
  //     statusCode: 400,
  //     error: "dateRangeEnd must be after dateRangeStart.",
  //   };
  // }

  const queryPromise = (query, params) =>
    new Promise((resolve, reject) => {
      pool.query(query, params, (error, results) => {
        if (error) {
          return reject(error);
        }
        resolve(results);
      });
    });

  try {
    // verify restaurant exists and is isActive = 0
    const restInfo = await queryPromise(
      "SELECT * FROM Restaurants WHERE restUUID = ?",
      [restUUID]
    );
    if (restInfo.length === 0) {
      return {
        statusCode: 400,
        error: "Restaurant does not exist.",
      };
    }

    // get all tables for the restaurant
    const benches = await queryPromise(
      "SELECT * FROM Benches WHERE restUUID = ?",
      [restUUID]
    );

    // get all reservations for the restaurant within the date range
    //ISO string is assumed to be in local timezone + have dateRangeStart at midnight and dateRangeEnd at 23:59
    const reservations = await queryPromise(
      "SELECT * FROM Reservations WHERE restUUID = ? AND reservationDateTime >= ? AND reservationDateTime <= ?",
      [restUUID, dateRangeStart, dateRangeEnd]
    );

    const daysClosed = await queryPromise(
      "SELECT * FROM ClosedDays WHERE restUUID = ? AND closedDate >= ? AND closedDate <= ?",
      [restUUID, dateRangeStart.slice(0, 10), dateRangeEnd.slice(0, 10)]
    );

    const daysInRange =
      new Date(dateRangeEnd).getDate() - new Date(dateRangeStart).getDate() + 1;

    let usage = [];
    for (let i = 0; i < daysInRange; i++) {
      //add i days to dateRangeStart
      const day = new Date(dateRangeStart);
      day.setDate(day.getDate() + i);
      const state = daysClosed.find(
        (closedDay) => new Date(closedDay.closedDate).getDate() == day.getDate()
      )
        ? "false"
        : "true";
      const tables = benches.map((bench) => {
        const times = reservations
          .filter(
            (res) =>
              res.benchUUID === bench.benchUUID &&
              new Date(res.reservationDateTime).toDateString() ===
                day.toDateString()
          )
          .map((reservation) => ({
            time: reservation.startTime,
            people: reservation.groupSize,
          }));

        return {
          name: bench.benchName,
          seats: bench.numSeats,
          times,
        };
      });

      usage.push({
        day: day.toISOString(),
        state,
        tables,
      });
    }

    return {
      statusCode: 200,
      availability: {
        startTime: restInfo[0].openingHour,
        endTime: restInfo[0].closingHour,
        usage,
      },
    };
  } catch (error) {
    console.error("ERROR:", error);
    return {
      statusCode: 500,
      error: error.message || "Internal server error.",
    };
  } finally {
    pool.end();
  }
};
