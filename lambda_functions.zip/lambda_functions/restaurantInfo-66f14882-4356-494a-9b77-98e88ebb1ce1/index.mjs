import mysql from 'mysql';

export const handler = async (event) => {
  const pool = mysql.createPool({
    host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "Netro7887",
    database: "tables4u",
    timezone: 'utc-5'
  });

  const restUUID = event.restUUID;
  const dateTime = event.dateTime;
  const numSeats = event.numberOfPeople;
  
  const query = `SELECT * FROM Reservations WHERE restUUID = ? AND reservationDateTime LIKE ?`;
  const query2 = `SELECT * FROM Benches WHERE restUUID = ? AND numSeats >= ?`;

  const queryPromise = (query, params) => {
    return new Promise((resolve, reject) => {
      pool.query(query, params, (error, results) => {
            if (error) {
              reject(error);
            } else {
                resolve(results);
            }
        });
    });
  };

  let response;
  try {
    const reservations = await queryPromise(query,[restUUID, dateTime.slice(0,10)+"%"]);
    const benches = await queryPromise(query2,[restUUID, numSeats]);

    let dict = {};

    //Note: if benches is empty, this never runs and we end up getting that every time is blocked
    benches.map((bench)=>(
      dict[bench.benchUUID]=Number(1<<24)
    ));

    reservations.map((reservation)=>(
      dict[reservation.benchUUID] ? dict[reservation.benchUUID] |= (1<<reservation.startTime) : {}
    ));

    let res = Number('0b1111111111111111111111111');
    Object.values(dict).map((val)=>(
      res &= val
    ));

    let body = [];

    for (let i = 0; i < 24; i++) {
      if((res>>i)&1!=0){
        body.push(i);
      }
    }

    response = {
      statusCode:200,
      body: JSON.stringify(body)
    };
  } catch (error) {
    response = {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    pool.end();
  }

  return response;
};