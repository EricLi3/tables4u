import mysql from 'mysql';

export const handler = async (event) => {
  const pool = mysql.createPool({
    host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "Netro7887",
    database: "tables4u"
  });

  const restName = event.restName;
  const dateTime = event.dateTime;
  const numSeats = event.numSeats;
  const numberToList = event.numberToList;
  
  const query = `SELECT restUUID, restName, address, openingHour, closingHour FROM Restaurants WHERE restName LIKE ? AND isActive = 1`;
  const query2 = `SELECT * FROM ClosedDays WHERE closedDate LIKE ?`;

  const queryPromise = (query, params) => {
    return new Promise((resolve, reject) => {
      pool.query(query, params, (error, results) => {
            if (error) {
              reject(error);
            } else {
                resolve(results);
            }
        });
    });
  };
  
  //search through restaurants and remove it if there is a closed day corresponding to the specific restaurant
  let response;
  try {
    const restaurants = await queryPromise(query,['%'+restName+'%']);
    const closedDays = await queryPromise(query2,['%'+dateTime.slice(0,10)+'%']);

    let openRestaurants = restaurants;

    restaurants.map((restaurant)=>(
      closedDays.map((closedDay)=>(
        restaurant.restUUID==closedDay.restUUID? openRestaurants=openRestaurants.filter(e=> e!== restaurant) : {}
      ))
    ));
    

    openRestaurants.sort((a, b) => (a.restName > b.restName) ? 1 : -1);
    
    response = {
      statusCode:200,
      body: JSON.stringify(openRestaurants.slice(0,numberToList))
    };
  } catch (error) {
    response = {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    pool.end();
  }

  return response;
};