import mysql from 'mysql';

export const handler = async (event) => {
  const pool = mysql.createPool({
    host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
    user: "admin",
    password: "Netro7887",
    database: "tables4u"
  });

  const restUUID = event.restUUID;
  const dateTime = event.dateTime;
  
  const query = `SELECT * FROM Reservations WHERE restUUID = ? AND reservationDateTime LIKE ?`;
  const query2 = `SELECT * FROM Benches WHERE restUUID = ?`;
  const query3 = `SELECT * FROM ClosedDays WHERE restUUID = ?`;

  const queryPromise = (query, params) => {
    return new Promise((resolve, reject) => {
      pool.query(query, params, (error, results) => {
            if (error) {
              reject(error);
            } else {
                resolve(results);
            }
        });
    });
  };

  let response;
  try {
    const reservations = await queryPromise(query,[restUUID, dateTime.slice(0,10)+"%"]);
    const benches = await queryPromise(query2,[restUUID]);
    const closedDays = await queryPromise(query3,[restUUID]);

    let dict = {};
    let body = [];

    benches.map((bench)=>(
      body.push({benchUUID: bench.benchUUID, name: bench.benchName, time: []})
    ));

    reservations.map((reservation)=>(
      body.map((bench)=>(
        bench.benchUUID == reservation.benchUUID ? bench.time.push(reservation.startTime) : {}
      ))
    ));

    let open = true;
    closedDays.map((closedDay)=>(
      closedDay.closedDate.toISOString().slice(0,10)==dateTime.slice(0,10) ? open = false : {}
    ));

    response = {
      statusCode:200,
      body: JSON.stringify({open: open,body})
    };
  } catch (error) {
    response = {
      statusCode: 400,
      body: JSON.stringify({ error: error.message })
    };
  } finally {
    pool.end();
  }

  return response;
};