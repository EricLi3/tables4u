import mysql from 'mysql';
import { v4 as uuidv4 } from 'uuid';

export const handler = async (event) => {
    // Specify credentials
    const pool = mysql.createPool({
        host: "calculatordb1.c7woyy8ecbg9.us-east-2.rds.amazonaws.com",
        user: "admin",
        password: "Netro7887",
        database: "tables4u"
    });

    const open = event.open;
    const restUUID = event.restUUID;
    const dateTime = event.dateTime.split("T")[0];

    const query = (sql, params) => {
        return new Promise((resolve, reject) => {
            pool.query(sql, params, (err, results) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(results);
                }
            });
        });
    };

    try {
        if (open) {
            await query("Delete from ClosedDays where restUUID = ? and closedDate = ?", [restUUID, dateTime]);
            return {
                statusCode: 200,
                status: "day opened"
            };
        } else {
            await query("Insert into ClosedDays (closeUUID, restUUID, closedDate) values (?, ?, ?)", [uuidv4(), restUUID, dateTime]);
            return {
                statusCode: 200,
                status: "day closed"
            };
        }
    } catch (err) {
        console.error(err);
        return {
            statusCode: 500,
            error: err
        };
    }
}